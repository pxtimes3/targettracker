--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 17.5 (Debian 17.5-1.pgdg120+1)
-- Dumped by pg_dump version 17.5

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = on;

DROP DATABASE local;
--
-- Name: local; Type: DATABASE; Schema: -; Owner: root
--

CREATE DATABASE local WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.utf8';


ALTER DATABASE local OWNER TO root;

\connect local

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = on;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: pg_database_owner
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO pg_database_owner;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: pg_database_owner
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: ammunitionType; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."ammunitionType" AS ENUM (
    'centerfire',
    'rimfire',
    'shotgun',
    'airgun'
);


ALTER TYPE public."ammunitionType" OWNER TO postgres;

--
-- Name: TYPE "ammunitionType"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TYPE public."ammunitionType" IS 'centerfire, rimfire, shotgun, airgun';


--
-- Name: angleunit; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.angleunit AS ENUM (
    'mil',
    'moa'
);


ALTER TYPE public.angleunit OWNER TO postgres;

--
-- Name: TYPE angleunit; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TYPE public.angleunit IS 'mil/moa';


--
-- Name: gunType; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."gunType" AS ENUM (
    'rifle',
    'pistol',
    'air-rifle',
    'air-pistol',
    'bow',
    'crossbow'
);


ALTER TYPE public."gunType" OWNER TO postgres;

--
-- Name: TYPE "gunType"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TYPE public."gunType" IS 'rifle, pistol, air-rifle, air-pistol, bow etc...';


--
-- Name: measurements; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.measurements AS ENUM (
    'metric',
    'imperial'
);


ALTER TYPE public.measurements OWNER TO postgres;

--
-- Name: TYPE measurements; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TYPE public.measurements IS 'metric or imperial';


--
-- Name: primertype; Type: TYPE; Schema: public; Owner: root
--

CREATE TYPE public.primertype AS ENUM (
    'small rifle',
    'small rifle magnum',
    'large rifle',
    'large rifle magnum',
    'small pistol',
    'small pistol magnum',
    'large pistol',
    'large pistol magnum',
    'shotgun'
);


ALTER TYPE public.primertype OWNER TO root;

--
-- Name: roles; Type: TYPE; Schema: public; Owner: root
--

CREATE TYPE public.roles AS ENUM (
    'user',
    'vip',
    'admin',
    'service'
);


ALTER TYPE public.roles OWNER TO root;

--
-- Name: sights; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.sights AS ENUM (
    'scope',
    'diopter',
    'open'
);


ALTER TYPE public.sights OWNER TO postgres;

--
-- Name: weight; Type: TYPE; Schema: public; Owner: root
--

CREATE TYPE public.weight AS ENUM (
    'g',
    'gr'
);


ALTER TYPE public.weight OWNER TO root;

--
-- Name: get_events_and_targets(uuid); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.get_events_and_targets(user_id_param uuid) RETURNS TABLE(event jsonb, targets jsonb)
    LANGUAGE plpgsql
    AS $$
begin
    return query
    select 
        to_jsonb(e.*) as event,
        to_jsonb(array_agg(t.*)) as targets
    from "events" e
    left join "targets" t on t.event_id = e.id
    where e.user_id = user_id_param
    group by e.id, e.*;
end;
$$;


ALTER FUNCTION public.get_events_and_targets(user_id_param uuid) OWNER TO postgres;

--
-- Name: get_user_data_and_flags(uuid); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.get_user_data_and_flags(user_id_param uuid) RETURNS TABLE(userdata jsonb, userflags jsonb)
    LANGUAGE plpgsql
    AS $$
begin
    return query
    select 
        to_jsonb(ud.*) as userData,
        to_jsonb(uf.*) as userFlags
    from "userData" ud
    left join "userFlags" uf on ud.user_id = uf.user_id
    where ud.user_id = user_id_param
    limit 1;
end;
$$;


ALTER FUNCTION public.get_user_data_and_flags(user_id_param uuid) OWNER TO postgres;

--
-- Name: get_user_firearms_data(uuid); Type: FUNCTION; Schema: public; Owner: root
--

CREATE FUNCTION public.get_user_firearms_data(user_uuid uuid) RETURNS TABLE(gun jsonb)
    LANGUAGE plpgsql
    AS $$
BEGIN
    RETURN QUERY
    WITH gun_groups AS (
        SELECT 
            g.id AS gun_id,
            gr.*
        FROM 
            gun g
        JOIN targets t ON g.id = t.gun_id
        JOIN groups gr ON t.id = gr.target_id
        WHERE g.user_id = user_uuid
    )
    SELECT 
        jsonb_build_object(
            'id', g.id,
            'gun_data', to_jsonb(g) - 'user_id',
            'targets', COALESCE(jsonb_agg(
                DISTINCT jsonb_build_object(
                    'id', t.id,
                    'data', to_jsonb(t) - 'user_id' - 'gun_id',
                    'groups', (
                        SELECT COALESCE(jsonb_agg(to_jsonb(gr) - 'user_id' - 'target_id'), '[]'::jsonb)
                        FROM groups gr
                        WHERE gr.target_id = t.id
                    )
                )
            ) FILTER (WHERE t.id IS NOT NULL), '[]'::jsonb),
            'averages', jsonb_build_object(
                'group_count', (SELECT COUNT(*) FROM gun_groups WHERE gun_groups.gun_id = g.id),
                'ccr', COALESCE((SELECT AVG(ccr) FROM gun_groups WHERE gun_groups.gun_id = g.id), 0),
                'cep', COALESCE((SELECT AVG(cep) FROM gun_groups WHERE gun_groups.gun_id = g.id), 0),
                'diagonal', COALESCE((SELECT AVG(diagonal) FROM gun_groups WHERE gun_groups.gun_id = g.id), 0),
                'es', COALESCE((SELECT AVG(es) FROM gun_groups WHERE gun_groups.gun_id = g.id), 0),
                'fom', COALESCE((SELECT AVG(fom) FROM gun_groups WHERE gun_groups.gun_id = g.id), 0),
                'meanradius', COALESCE((SELECT AVG(meanradius) FROM gun_groups WHERE gun_groups.gun_id = g.id), 0),
                'size', COALESCE((SELECT AVG(size) FROM gun_groups WHERE gun_groups.gun_id = g.id), 0),
                'sd_x', COALESCE((SELECT AVG(sd_x) FROM gun_groups WHERE gun_groups.gun_id = g.id), 0),
                'sd_y', COALESCE((SELECT AVG(sd_y) FROM gun_groups WHERE gun_groups.gun_id = g.id), 0),
                'variance_x', COALESCE((SELECT AVG(variance_x) FROM gun_groups WHERE gun_groups.gun_id = g.id), 0),
                'variance_y', COALESCE((SELECT AVG(variance_y) FROM gun_groups WHERE gun_groups.gun_id = g.id), 0)
            )
        ) AS gun
    FROM 
        gun g
    LEFT JOIN 
        targets t ON g.id = t.gun_id
    WHERE 
        g.user_id = user_uuid
    GROUP BY 
        g.id, g.name, g.*
    ORDER BY 
        g.name;
END;
$$;


ALTER FUNCTION public.get_user_firearms_data(user_uuid uuid) OWNER TO root;

--
-- Name: old_get_user_firearms_data(uuid); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.old_get_user_firearms_data(user_uuid uuid) RETURNS TABLE(gun_id uuid, gun_data jsonb, targets jsonb, averages jsonb)
    LANGUAGE plpgsql
    AS $$BEGIN
    RETURN QUERY
    WITH gun_groups AS (
        SELECT 
            g.id AS gun_id,
            gr.*
        FROM 
            gun g
        JOIN targets t ON g.id = t.gun_id
        JOIN groups gr ON t.id = gr.target_id
        WHERE g.user_id = user_uuid
    )
    SELECT 
        g.id AS gun_id,
        to_jsonb(g) - 'user_id' AS gun_data,
        COALESCE(jsonb_agg(
            DISTINCT jsonb_build_object(
                'id', t.id,
                'data', to_jsonb(t) - 'user_id' - 'gun_id',
                'groups', (
                    SELECT COALESCE(jsonb_agg(to_jsonb(gr) - 'user_id' - 'target_id'), '[]'::jsonb)
                    FROM groups gr
                    WHERE gr.target_id = t.id
                )
            )
        ) FILTER (WHERE t.id IS NOT NULL), '[]'::jsonb) AS targets,
        jsonb_build_object(
            'group_count', (SELECT COUNT(*) FROM gun_groups WHERE gun_groups.gun_id = g.id),
            'ccr', COALESCE((SELECT AVG(ccr) FROM gun_groups WHERE gun_groups.gun_id = g.id), 0),
            'cep', COALESCE((SELECT AVG(cep) FROM gun_groups WHERE gun_groups.gun_id = g.id), 0),
            'diagonal', COALESCE((SELECT AVG(diagonal) FROM gun_groups WHERE gun_groups.gun_id = g.id), 0),
            'es', COALESCE((SELECT AVG(es) FROM gun_groups WHERE gun_groups.gun_id = g.id), 0),
            'fom', COALESCE((SELECT AVG(fom) FROM gun_groups WHERE gun_groups.gun_id = g.id), 0),
            'meanradius', COALESCE((SELECT AVG(meanradius) FROM gun_groups WHERE gun_groups.gun_id = g.id), 0),
            'size', COALESCE((SELECT AVG(size) FROM gun_groups WHERE gun_groups.gun_id = g.id), 0),
            'sd_x', COALESCE((SELECT AVG(sd_x) FROM gun_groups WHERE gun_groups.gun_id = g.id), 0),
            'sd_y', COALESCE((SELECT AVG(sd_y) FROM gun_groups WHERE gun_groups.gun_id = g.id), 0),
            'variance_x', COALESCE((SELECT AVG(variance_x) FROM gun_groups WHERE gun_groups.gun_id = g.id), 0),
            'variance_y', COALESCE((SELECT AVG(variance_y) FROM gun_groups WHERE gun_groups.gun_id = g.id), 0)
        ) AS averages
    FROM 
        gun g
    LEFT JOIN 
        targets t ON g.id = t.gun_id
    WHERE 
        g.user_id = user_uuid
    GROUP BY 
        g.id, g.name, g.*
    ORDER BY 
        g.name;
END;$$;


ALTER FUNCTION public.old_get_user_firearms_data(user_uuid uuid) OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: ammunition; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ammunition (
    user_id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    name text NOT NULL,
    type public."ammunitionType" NOT NULL,
    manufacturer_case text,
    manufacturer_bullet text,
    manufacturer_primer text,
    manufacturer_propellant text,
    propellant_charge double precision,
    bullet_name text,
    caliber text,
    bullet_weight double precision,
    primer_type public.primertype,
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    manufacturer_brand text,
    bullet_weight_unit public.weight,
    propellant_weight_unit public.weight,
    manufacturer_name text,
    caliber_mm double precision,
    note text,
    date date,
    propellant_name text,
    "primerName" text,
    cartridge_oal_unit public.measurements,
    cartridge_oal double precision,
    bullet_bc_g1 double precision,
    bullet_bc_g7 double precision,
    bullet_sd double precision,
    caliber_unit public.measurements,
    CONSTRAINT ammunition_manufacturer_brand_check CHECK ((length(manufacturer_brand) < 100))
);


ALTER TABLE public.ammunition OWNER TO postgres;

--
-- Name: TABLE ammunition; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.ammunition IS 'Users saved ammunition';


--
-- Name: COLUMN ammunition.manufacturer_brand; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.ammunition.manufacturer_brand IS 'Norma BONDSTRIKE etc...';


--
-- Name: analysis; Type: TABLE; Schema: public; Owner: service
--

CREATE TABLE public.analysis (
    id uuid DEFAULT gen_random_uuid(),
    submitted timestamp without time zone DEFAULT now(),
    updated timestamp without time zone DEFAULT now(),
    user_id uuid NOT NULL,
    image_name text NOT NULL,
    result text,
    error text
);


ALTER TABLE public.analysis OWNER TO service;

--
-- Name: events; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.events (
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    user_id uuid NOT NULL,
    name text DEFAULT ''::text NOT NULL,
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    location text,
    note text,
    date timestamp with time zone
);


ALTER TABLE public.events OWNER TO postgres;

--
-- Name: TABLE events; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.events IS 'collection of user targets';


--
-- Name: COLUMN events.user_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.events.user_id IS 'User UUID';


--
-- Name: faq; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.faq (
    id uuid DEFAULT gen_random_uuid(),
    question text NOT NULL,
    answer text NOT NULL,
    "order" integer DEFAULT 0,
    created timestamp without time zone DEFAULT now(),
    updated timestamp without time zone DEFAULT now()
);


ALTER TABLE public.faq OWNER TO root;

--
-- Name: groups; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.groups (
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    group_number bigint DEFAULT '1'::bigint NOT NULL,
    meanradius double precision,
    cep double precision,
    variance_x double precision,
    variance_y double precision,
    sd_x double precision,
    sd_y double precision,
    es double precision,
    diagonal double precision,
    fom double precision,
    ccr double precision,
    size double precision,
    user_id uuid NOT NULL,
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    target_id uuid
);


ALTER TABLE public.groups OWNER TO postgres;

--
-- Name: gun; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.gun (
    user_id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    name text NOT NULL,
    type public."gunType" NOT NULL,
    manufacturer text,
    caliber text NOT NULL,
    sights text,
    barrel text,
    "barrelLength" double precision,
    stock text,
    note text,
    manufacturer_other text,
    barrel_twist text,
    picture_original text,
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    caliber_mm double precision,
    model text,
    barrel_length_unit public.measurements,
    barrel_twist_unit public.measurements
);


ALTER TABLE public.gun OWNER TO postgres;

--
-- Name: TABLE gun; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.gun IS 'user guns';


--
-- Name: invitecodes; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.invitecodes (
    id uuid DEFAULT gen_random_uuid(),
    code uuid DEFAULT gen_random_uuid(),
    user_id uuid NOT NULL,
    invitee_email text,
    inivite_sent timestamp without time zone,
    accepted boolean DEFAULT false,
    active boolean DEFAULT true
);


ALTER TABLE public.invitecodes OWNER TO root;

--
-- Name: load_recipe; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.load_recipe (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    name text NOT NULL,
    caliber text,
    caliber_mm double precision,
    caliber_unit public.measurements,
    manufacturer_case text,
    manufacturer_bullet text,
    bullet_name text,
    bullet_weight double precision,
    bullet_weight_unit public.weight,
    bullet_bc_g1 double precision,
    bullet_bc_g7 double precision,
    bullet_sd double precision,
    manufacturer_propellant text,
    propellant_name text,
    note text,
    date date,
    is_factory boolean DEFAULT false NOT NULL,
    type public."ammunitionType",
    bullet_id uuid
);


ALTER TABLE public.load_recipe OWNER TO postgres;

--
-- Name: TABLE load_recipe; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.load_recipe IS 'Base load recipes created by users';


--
-- Name: load_variation; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.load_variation (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    recipe_id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    name text,
    propellant_charge double precision,
    propellant_weight_unit public.weight,
    cartridge_oal double precision,
    cartridge_oal_unit public.measurements,
    lot_number text,
    production_date date,
    note text,
    primer_type public.primertype,
    primer_name text,
    manufacturer_primer text
);


ALTER TABLE public.load_variation OWNER TO postgres;

--
-- Name: TABLE load_variation; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.load_variation IS 'Specific load variations based on a recipe';


--
-- Name: manufacturers; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.manufacturers (
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    name text NOT NULL,
    ammunition boolean DEFAULT false NOT NULL,
    guns boolean DEFAULT false NOT NULL,
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    airguns boolean DEFAULT false NOT NULL,
    popularity bigint DEFAULT '0'::bigint,
    ammunition_air boolean DEFAULT false NOT NULL
);


ALTER TABLE public.manufacturers OWNER TO postgres;

--
-- Name: COLUMN manufacturers.ammunition_air; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.manufacturers.ammunition_air IS 'pellets';


--
-- Name: session; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.session (
    id text NOT NULL,
    user_id uuid NOT NULL,
    expires_at timestamp with time zone NOT NULL
);


ALTER TABLE public.session OWNER TO root;

--
-- Name: settings; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.settings (
    id uuid DEFAULT gen_random_uuid(),
    user_id uuid NOT NULL,
    cursortips boolean DEFAULT true,
    isometrics boolean DEFAULT true,
    mils boolean DEFAULT true,
    showallshots boolean DEFAULT true,
    editorhelpclosed boolean DEFAULT false,
    lasttargettype text,
    lastcaliber uuid,
    lastgun uuid
);


ALTER TABLE public.settings OWNER TO root;

--
-- Name: sight; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sight (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    type public.sights,
    zoom text,
    objective double precision,
    objective_unit public.measurements,
    height_over_bore double precision,
    height_over_bore_unit public.measurements,
    adjustments public.angleunit,
    click double precision,
    manufacturer text,
    model text,
    user_id uuid NOT NULL
);


ALTER TABLE public.sight OWNER TO postgres;

--
-- Name: targets; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.targets (
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    user_id uuid NOT NULL,
    gun_id uuid NOT NULL,
    ammunition_id uuid NOT NULL,
    event_id uuid NOT NULL,
    data json NOT NULL,
    data_size double precision,
    data_mr double precision,
    data_es double precision,
    image_url text,
    image_thumbnail_url text,
    data_groups bigint DEFAULT '1'::bigint,
    name text,
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    note text,
    public boolean DEFAULT false
);


ALTER TABLE public.targets OWNER TO postgres;

--
-- Name: TABLE targets; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.targets IS 'User targets';


--
-- Name: user; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public."user" (
    id uuid NOT NULL,
    username text NOT NULL,
    password_hash text NOT NULL,
    role public.roles DEFAULT 'user'::public.roles,
    email text NOT NULL,
    "invitedBy" uuid,
    "inviteCode" uuid,
    "verificationCode" uuid NOT NULL,
    verified boolean DEFAULT false,
    "createdAt" timestamp without time zone DEFAULT now()
);


ALTER TABLE public."user" OWNER TO root;

--
-- Name: userflags; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.userflags (
    id bigint NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    user_id uuid,
    unitsystem public.measurements DEFAULT 'metric'::public.measurements,
    angleunit public.angleunit DEFAULT 'mil'::public.angleunit,
    target_showall boolean DEFAULT true
);


ALTER TABLE public.userflags OWNER TO postgres;

--
-- Name: TABLE userflags; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.userflags IS 'Flags for user; UnitTypes etc...';


--
-- Name: userFlags_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.userflags ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public."userFlags_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: userdata; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.userdata (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    user_id uuid,
    name text,
    surname text
);


ALTER TABLE public.userdata OWNER TO postgres;

--
-- Data for Name: ammunition; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3563.dat

--
-- Data for Name: analysis; Type: TABLE DATA; Schema: public; Owner: service
--

\i $$PATH$$/3548.dat

--
-- Data for Name: events; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3557.dat

--
-- Data for Name: faq; Type: TABLE DATA; Schema: public; Owner: root
--

\i $$PATH$$/3549.dat

--
-- Data for Name: groups; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3554.dat

--
-- Data for Name: gun; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3556.dat

--
-- Data for Name: invitecodes; Type: TABLE DATA; Schema: public; Owner: root
--

\i $$PATH$$/3550.dat

--
-- Data for Name: load_recipe; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3564.dat

--
-- Data for Name: load_variation; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3565.dat

--
-- Data for Name: manufacturers; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3558.dat

--
-- Data for Name: session; Type: TABLE DATA; Schema: public; Owner: root
--

\i $$PATH$$/3551.dat

--
-- Data for Name: settings; Type: TABLE DATA; Schema: public; Owner: root
--

\i $$PATH$$/3553.dat

--
-- Data for Name: sight; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3559.dat

--
-- Data for Name: targets; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3555.dat

--
-- Data for Name: user; Type: TABLE DATA; Schema: public; Owner: root
--

\i $$PATH$$/3552.dat

--
-- Data for Name: userdata; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3560.dat

--
-- Data for Name: userflags; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3561.dat

--
-- Name: userFlags_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."userFlags_id_seq"', 1, false);


--
-- Name: gun id_primary_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.gun
    ADD CONSTRAINT id_primary_key PRIMARY KEY (id);


--
-- Name: load_recipe load_recipe_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.load_recipe
    ADD CONSTRAINT load_recipe_pkey PRIMARY KEY (id);


--
-- Name: load_variation load_variation_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.load_variation
    ADD CONSTRAINT load_variation_pkey PRIMARY KEY (id);


--
-- Name: session session_pkey; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.session
    ADD CONSTRAINT session_pkey PRIMARY KEY (id);


--
-- Name: user user_email_unique; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public."user"
    ADD CONSTRAINT user_email_unique UNIQUE (email);


--
-- Name: user user_pkey; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public."user"
    ADD CONSTRAINT user_pkey PRIMARY KEY (id);


--
-- Name: user user_username_unique; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public."user"
    ADD CONSTRAINT user_username_unique UNIQUE (username);


--
-- Name: fki_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX fki_user_id ON public.groups USING btree (user_id);


--
-- Name: fki_userid; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX fki_userid ON public.gun USING btree (user_id);


--
-- Name: analysis analysis_user_id_user_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: service
--

ALTER TABLE ONLY public.analysis
    ADD CONSTRAINT analysis_user_id_user_id_fk FOREIGN KEY (user_id) REFERENCES public."user"(id) ON DELETE CASCADE;


--
-- Name: invitecodes invitecodes_user_user_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.invitecodes
    ADD CONSTRAINT invitecodes_user_user_id_fk FOREIGN KEY (user_id) REFERENCES public."user"(id) ON DELETE CASCADE;


--
-- Name: load_recipe load_recipe_user_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.load_recipe
    ADD CONSTRAINT load_recipe_user_fkey FOREIGN KEY (user_id) REFERENCES public."user"(id) MATCH FULL ON DELETE CASCADE;


--
-- Name: load_variation load_variation_recipe_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.load_variation
    ADD CONSTRAINT load_variation_recipe_fkey FOREIGN KEY (recipe_id) REFERENCES public.load_recipe(id) MATCH FULL ON DELETE CASCADE;


--
-- Name: session session_user_id_user_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.session
    ADD CONSTRAINT session_user_id_user_id_fk FOREIGN KEY (user_id) REFERENCES public."user"(id) ON DELETE CASCADE;


--
-- Name: settings settings_user_id_user_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.settings
    ADD CONSTRAINT settings_user_id_user_id_fk FOREIGN KEY (user_id) REFERENCES public."user"(id) ON DELETE CASCADE;


--
-- Name: groups user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.groups
    ADD CONSTRAINT user_id FOREIGN KEY (user_id) REFERENCES public."user"(id) NOT VALID;


--
-- Name: gun userid; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.gun
    ADD CONSTRAINT userid FOREIGN KEY (user_id) REFERENCES public."user"(id) MATCH FULL ON DELETE CASCADE NOT VALID;


--
-- Name: events userid; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.events
    ADD CONSTRAINT userid FOREIGN KEY (user_id) REFERENCES public."user"(id) MATCH FULL ON DELETE CASCADE NOT VALID;


--
-- Name: groups userid; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.groups
    ADD CONSTRAINT userid FOREIGN KEY (user_id) REFERENCES public."user"(id) MATCH FULL ON DELETE CASCADE NOT VALID;


--
-- Name: invitecodes userid; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.invitecodes
    ADD CONSTRAINT userid FOREIGN KEY (user_id) REFERENCES public."user"(id) MATCH FULL ON DELETE CASCADE NOT VALID;


--
-- Name: settings userid; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.settings
    ADD CONSTRAINT userid FOREIGN KEY (user_id) REFERENCES public."user"(id) MATCH FULL ON DELETE CASCADE NOT VALID;


--
-- Name: targets userid; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.targets
    ADD CONSTRAINT userid FOREIGN KEY (user_id) REFERENCES public."user"(id) MATCH FULL ON DELETE CASCADE NOT VALID;


--
-- Name: userdata userid; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.userdata
    ADD CONSTRAINT userid FOREIGN KEY (user_id) REFERENCES public."user"(id) MATCH FULL ON DELETE CASCADE NOT VALID;


--
-- Name: userflags userid; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.userflags
    ADD CONSTRAINT userid FOREIGN KEY (user_id) REFERENCES public."user"(id) MATCH FULL ON DELETE CASCADE NOT VALID;


--
-- Name: sight userid; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sight
    ADD CONSTRAINT userid FOREIGN KEY (user_id) REFERENCES public."user"(id) MATCH FULL ON DELETE CASCADE NOT VALID;


--
-- Name: ammunition userid; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ammunition
    ADD CONSTRAINT userid FOREIGN KEY (user_id) REFERENCES public."user"(id) MATCH FULL ON DELETE CASCADE;


--
-- Name: analysis admin access all; Type: POLICY; Schema: public; Owner: service
--

CREATE POLICY "admin access all" ON public.analysis TO admin;


--
-- Name: faq admin access all; Type: POLICY; Schema: public; Owner: root
--

CREATE POLICY "admin access all" ON public.faq TO admin;


--
-- Name: invitecodes admin access all; Type: POLICY; Schema: public; Owner: root
--

CREATE POLICY "admin access all" ON public.invitecodes TO admin;


--
-- Name: user admin access all; Type: POLICY; Schema: public; Owner: root
--

CREATE POLICY "admin access all" ON public."user" TO admin;


--
-- Name: analysis; Type: ROW SECURITY; Schema: public; Owner: service
--

ALTER TABLE public.analysis ENABLE ROW LEVEL SECURITY;

--
-- Name: faq; Type: ROW SECURITY; Schema: public; Owner: root
--

ALTER TABLE public.faq ENABLE ROW LEVEL SECURITY;

--
-- Name: invitecodes; Type: ROW SECURITY; Schema: public; Owner: root
--

ALTER TABLE public.invitecodes ENABLE ROW LEVEL SECURITY;

--
-- Name: analysis public can view; Type: POLICY; Schema: public; Owner: service
--

CREATE POLICY "public can view" ON public.analysis FOR SELECT;


--
-- Name: faq public can view; Type: POLICY; Schema: public; Owner: root
--

CREATE POLICY "public can view" ON public.faq FOR SELECT;


--
-- Name: invitecodes public can view; Type: POLICY; Schema: public; Owner: root
--

CREATE POLICY "public can view" ON public.invitecodes FOR SELECT;


--
-- Name: user public can view; Type: POLICY; Schema: public; Owner: root
--

CREATE POLICY "public can view" ON public."user" FOR SELECT;


--
-- Name: analysis service; Type: POLICY; Schema: public; Owner: service
--

CREATE POLICY service ON public.analysis TO service;


--
-- Name: user; Type: ROW SECURITY; Schema: public; Owner: root
--

ALTER TABLE public."user" ENABLE ROW LEVEL SECURITY;

--
-- Name: TABLE analysis; Type: ACL; Schema: public; Owner: service
--

GRANT ALL ON TABLE public.analysis TO root;


--
-- PostgreSQL database dump complete
--

